package com.nova.keyboard

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color

class KbTheme(
    val name: String,
    val bg: Int,
    val key: Int,
    val fn: Int,
    val pressed: Int,
    val text: Int,
    val sub: Int,
    val action: Int,
    val actionText: Int
)

object Themes {
    private fun c(s: String): Int = Color.parseColor(s)

    // Koyu: ekran görüntüsündeki Gboard tarzı
    val DARK = KbTheme(
        "dark", c("#1F2023"), c("#3C3C40"), c("#4A4B50"), c("#62636A"),
        c("#E8EAED"), c("#9AA0A6"), c("#A8C7FA"), c("#062E6F")
    )
    val LIGHT = KbTheme(
        "light", c("#E8EAEE"), c("#FFFFFF"), c("#CDD1D9"), c("#B4BAC5"),
        c("#1F1F1F"), c("#5F6368"), c("#C2D7FB"), c("#041E49")
    )
    val BLACK = KbTheme(
        "black", c("#000000"), c("#1A1A1C"), c("#2A2A2E"), c("#44444A"),
        c("#FFFFFF"), c("#8A8F98"), c("#3B82F6"), c("#FFFFFF")
    )

    fun isNight(ctx: Context): Boolean {
        val m = ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return m == Configuration.UI_MODE_NIGHT_YES
    }

    fun resolve(ctx: Context, name: String): KbTheme {
        val n = if (name == "system") (if (isNight(ctx)) "dark" else "light") else name
        return when (n) {
            "light" -> LIGHT
            "black" -> BLACK
            else -> DARK
        }
    }

    fun label(name: String): String = when (name) {
        "dark" -> "Koyu"
        "light" -> "Açık"
        "black" -> "Siyah"
        else -> "Sistem"
    }
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

object EmojiData {
    private fun l(s: String): List<String> = s.trim().split(" ").filter { it.isNotEmpty() }

    val CATS: List<Pair<String, List<String>>> = listOf(
        "😀" to l(
            "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😜 🤪 😝 🤑 🤗 🤭 🤫 🤔 🤐 🤨 " +
                "😐 😑 😶 😏 😒 🙄 😬 🤥 😔 😪 🤤 😴 😷 🤒 🤕 🤢 🤮 🥵 🥶 🥴 😵 🤯 🤠 🥳 😎 🤓 🧐 😕 😟 🙁 😮 😯 " +
                "😲 😳 🥺 😦 😧 😨 😰 😥 😢 😭 😱 😖 😣 😞 😓 😩 😫 🥱 😤 😡 😠 🤬 😈 👿 💀 💩 🤡 👻 👽 🤖"
        ),
        "👍" to l(
            "👍 👎 👌 🤌 🤏 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐️ 🖖 👋 🤝 🙏 ✍️ 💪 👏 🙌 👐 🤲 " +
                "🤷 🤦 🙋 💁 🙆 🙅 🙇 💃 🕺 🚶 🏃 👨 👩 👧 👦 👶 👴 👵 🧔 👮 🕵️ 👷 👸 🤴 🎅 🧙 🧛 🧟"
        ),
        "🐶" to l(
            "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🐛 " +
                "🦋 🐌 🐞 🐜 🕷️ 🦂 🐢 🐍 🦎 🐙 🦑 🦐 🦀 🐠 🐟 🐬 🐳 🐋 🦈 🐊 🐘 🦒 🌵 🌲 🌳 🌴 🌸 🌼 🌻 🌹 🍀 🍁 " +
                "🌍 🌙 ⭐ 🌞 ☁️ 🌈 ⚡ 🔥 💧 ❄️"
        ),
        "🍔" to l(
            "🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🍑 🍍 🥥 🥝 🍅 🥑 🥦 🥕 🌽 🌶️ 🥔 🍞 🥐 🧀 🥚 🍳 🥓 🥩 🍗 🍖 🌭 " +
                "🍔 🍟 🍕 🥪 🌮 🌯 🥙 🍝 🍜 🍲 🍣 🍤 🍙 🍚 🍦 🍩 🍪 🎂 🍰 🍫 🍬 🍭 🍯 ☕ 🍵 🥛 🍺 🍷 🥂 🍸 🥤"
        ),
        "⚽" to l(
            "⚽ 🏀 🏈 ⚾ 🎾 🏐 🏉 🎱 🏓 🏸 🥊 🥋 ⛳ 🏹 🎣 ⛸️ 🎿 🏂 🏋️ 🤸 🚴 🏊 🧘 🏆 🥇 🥈 🥉 🏅 🎖️ " +
                "🎮 🎯 🎲 🧩 🎭 🎨 🎬 🎤 🎧 🎼 🎹 🥁 🎷 🎺 🎸 🎻 🎳"
        ),
        "🚗" to l(
            "🚗 🚕 🚙 🚌 🚎 🏎️ 🚓 🚑 🚒 🚚 🚜 🏍️ 🚲 🛴 ✈️ 🚀 🛸 🚁 ⛵ 🚤 🛳️ ⚓ 🚂 🚆 🚇 🚉 🏠 🏡 🏢 🏥 🏦 " +
                "🏫 🏰 🕌 ⛪ 🗽 🗼 🌉 🎡 🎢 ⛺ 🏖️ 🏝️ 🏔️ 🌋 🗺️ 🧭"
        ),
        "💡" to l(
            "⌚ 📱 💻 ⌨️ 🖥️ 🖨️ 🖱️ 💽 💾 📷 📹 🎥 📺 📻 ⏰ 🔋 🔌 💡 🔦 📚 📖 📝 ✏️ 📌 📎 ✂️ 🔒 🔑 🔨 " +
                "🔧 ⚙️ 🧲 💣 💊 💉 🔬 🔭 📡 💰 💳 💎 ⚖️ 🛒 🎁 🎈 📦 ✉️ 📧 📅 📊 🧾"
        ),
        "❤️" to l(
            "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💯 ✅ ❌ ❓ ❗ ‼️ ⚠️ ♻️ ➕ ➖ ➗ ✖️ " +
                "💲 ✔️ ☑️ 🔴 🟠 🟡 🟢 🔵 🟣 ⚫ ⚪ 🔔 🔕 🎵 🎶 ➡️ ⬅️ ⬆️ ⬇️ 🔝 🆗 🆕 🆓"
        )
    )
}
