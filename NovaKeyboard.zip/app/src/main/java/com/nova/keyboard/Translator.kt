package com.nova.keyboard

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Çeviri istemcisi. Yalnızca kullanıcı "Çevir"e bastığında çalışır; hiçbir şey saklanmaz. */
object Translator {

    val NAMES = mapOf(
        "tr" to "Türkçe", "en" to "English", "de" to "Deutsch", "fr" to "Français",
        "es" to "Español", "it" to "Italiano", "ru" to "Русский", "ar" to "العربية",
        "pt" to "Português", "nl" to "Nederlands", "ja" to "日本語", "ko" to "한국어",
        "zh-CN" to "中文", "az" to "Azərbaycan", "fa" to "فارسی", "uk" to "Українська"
    )

    /** Döner: (çeviri, algılanan dil kodu). */
    fun translate(text: String, target: String): Pair<String, String> {
        return try {
            google(text.take(1500), target)
        } catch (e: Exception) {
            myMemory(text.take(480), target)
        }
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "GET"
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) NovaKeyboard")
        val code = c.responseCode
        if (code !in 200..299) throw Exception("HTTP $code")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun google(text: String, target: String): Pair<String, String> {
        val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=" +
            URLEncoder.encode(target, "UTF-8") + "&dt=t&q=" + URLEncoder.encode(text, "UTF-8")
        val arr = JSONArray(get(url))
        val segs = arr.getJSONArray(0)
        val sb = StringBuilder()
        for (i in 0 until segs.length()) {
            val s = segs.optJSONArray(i) ?: continue
            sb.append(s.optString(0, ""))
        }
        val det = if (arr.length() > 2) arr.optString(2, "") else ""
        if (sb.isBlank()) throw Exception("Boş yanıt")
        return Pair(sb.toString(), det)
    }

    private fun myMemory(text: String, target: String): Pair<String, String> {
        val url = "https://api.mymemory.translated.net/get?q=" + URLEncoder.encode(text, "UTF-8") +
            "&langpair=" + URLEncoder.encode("autodetect|$target", "UTF-8")
        val o = JSONObject(get(url))
        val t = o.getJSONObject("responseData").optString("translatedText", "")
        if (t.isBlank()) throw Exception("Çeviri alınamadı")
        return Pair(t, "")
    }
}
