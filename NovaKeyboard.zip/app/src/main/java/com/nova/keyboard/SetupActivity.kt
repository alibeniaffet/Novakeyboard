package com.nova.keyboard

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SetupActivity : Activity() {

    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var sp: SharedPreferences
    private lateinit var scroll: ScrollView
    private lateinit var col: LinearLayout
    private var dark = false
    private var cBg = 0
    private var cCard = 0
    private var cText = 0
    private var cSub = 0
    private val accent = Color.parseColor("#3B82F6")

    private var enableTv: TextView? = null
    private var selectTv: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sp = getSharedPreferences("kb", Context.MODE_PRIVATE)
        dark = Themes.isNight(this)
        cBg = Color.parseColor(if (dark) "#121214" else "#F4F5F7")
        cCard = Color.parseColor(if (dark) "#1E1F23" else "#FFFFFF")
        cText = Color.parseColor(if (dark) "#E8EAED" else "#202124")
        cSub = Color.parseColor(if (dark) "#9AA0A6" else "#5F6368")
        render()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    // ---------------------------------------------------------------- yardımcılar

    private fun rounded(color: Int, r: Int, stroke: Int = 0): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(r).toFloat()
        if (stroke != 0) d.setStroke(dp(2), stroke)
        return d
    }

    private fun text(s: String, size: Float = 15f, color: Int = cText, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun lp(top: Int = 10): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(MP, WC)
        l.topMargin = dp(top)
        return l
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = rounded(cCard, 16)
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        return c
    }

    private fun button(label: String, filled: Boolean, onClick: () -> Unit): TextView {
        val b = text(label, 15f, if (filled) Color.WHITE else accent, true)
        b.gravity = Gravity.CENTER
        b.background = rounded(if (filled) accent else Color.TRANSPARENT, 12, if (filled) 0 else accent)
        b.setPadding(dp(14), dp(12), dp(14), dp(12))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun section(s: String): TextView {
        val t = text(s, 13f, accent, true)
        t.setPadding(dp(4), dp(22), 0, dp(2))
        return t
    }

    // ---------------------------------------------------------------- arayüz

    private fun render() {
        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(20), dp(16), dp(40))

        col.addView(text("⌨️ Nova Klavye", 26f, cText, true))
        col.addView(text("Gizlilik odaklı klavye: kelime öğrenmez, yazdıklarını kaydetmez. İnternet yalnızca sen çeviri istediğinde kullanılır.", 14f, cSub))

        // Kurulum
        col.addView(section("KURULUM"))
        val setup = card()
        enableTv = text("", 14f)
        setup.addView(enableTv)
        setup.addView(button("1) Klavyeyi etkinleştir", true) {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }, lp(8))
        selectTv = text("", 14f)
        selectTv!!.setPadding(0, dp(14), 0, 0)
        setup.addView(selectTv)
        setup.addView(button("2) Klavyeyi seç", false) {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }, lp(8))
        col.addView(setup, lp(8))
        refreshStatus()

        // Tema
        col.addView(section("TEMA"))
        val current = sp.getString("theme", "system") ?: "system"
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val names = listOf("system", "dark", "light", "black")
        for (n in names) {
            val item = LinearLayout(this)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER_HORIZONTAL
            item.setPadding(dp(4), dp(6), dp(4), dp(6))
            val selected = n == current
            item.background = rounded(cCard, 14, if (selected) accent else Color.TRANSPARENT)
            item.addView(preview(Themes.resolve(this, n)))
            val lb = text(Themes.label(n), 12f, if (selected) accent else cText, selected)
            lb.gravity = Gravity.CENTER
            item.addView(lb)
            item.setOnClickListener {
                sp.edit().putString("theme", n).apply()
                rerender()
            }
            val l = LinearLayout.LayoutParams(0, WC, 1f)
            l.setMargins(dp(3), 0, dp(3), 0)
            row.addView(item, l)
        }
        col.addView(row, lp(8))

        // Düzen
        col.addView(section("DÜZEN"))
        val layout = card()
        layout.addView(choiceRow("Tek el modu", "onehand", "off",
            listOf("off" to "Kapalı", "left" to "Sol", "right" to "Sağ")))
        layout.addView(toggleRow("Kayan mod", "Klavyeyi ekranda serbestçe sürükle (deneysel)", "floating", false))
        layout.addView(choiceRowInt("Klavye yüksekliği", "height", 1,
            listOf(0 to "Küçük", 1 to "Orta", 2 to "Büyük")))
        layout.addView(choiceRow("Başlangıç dili", "lang", "tr", listOf("tr" to "Türkçe", "en" to "English")))
        col.addView(layout, lp(8))

        // Davranış
        col.addView(section("DAVRANIŞ"))
        val beh = card()
        beh.addView(toggleRow("Titreşim", "Tuşlara basınca hafif titreşim", "haptic", true))
        beh.addView(toggleRow("Tuş sesi", "Basınca ses çıkar", "sound", false))
        beh.addView(toggleRow("Otomatik büyük harf", "Cümle başında büyük harfle başla", "autocap", true))
        beh.addView(toggleRow("Pano geçmişi", "Kopyaladıklarını yalnızca bellekte tut (diske yazılmaz)", "clip_hist", true))
        col.addView(beh, lp(8))
        col.addView(button("Kayan klavye konumunu sıfırla", false) {
            sp.edit().remove("float_x").remove("float_y").apply()
        }, lp(10))

        // Gizlilik
        col.addView(section("GİZLİLİK"))
        val priv = card()
        priv.addView(text(
            "• Yazdıkların kaydedilmez; kelime öğrenme / öneri / otomatik düzeltme yok.\n" +
                "• Kişisel sözlük ve yazı geçmişi yok. Yedekleme kapalı.\n" +
                "• İnternet izni yalnızca ÇEVİRİ için var: metin ancak sen “Çevir”e basınca " +
                "Google çeviri sunucusuna gönderilir (olmazsa MyMemory). Başka hiçbir yerde ağ kullanılmaz.\n" +
                "• Pano öğeleri sadece bellekte durur; hassas işaretli kopyalar alınmaz.\n\n" +
                "Not: Sesli yazma telefonundaki Google ses tanıma servisini kullanır; ses o serviste işlenir.",
            13f, cText
        ))
        col.addView(priv, lp(8))

        // Deneme alanı
        col.addView(section("DENE"))
        val test = EditText(this)
        test.hint = "Klavyeyi burada dene…"
        test.setHintTextColor(cSub)
        test.setTextColor(cText)
        test.background = rounded(cCard, 14)
        test.setPadding(dp(16), dp(14), dp(16), dp(14))
        test.minLines = 3
        test.gravity = Gravity.TOP
        test.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        col.addView(test, lp(8))

        scroll = ScrollView(this)
        scroll.setBackgroundColor(cBg)
        scroll.isFillViewport = true
        scroll.clipToPadding = false
        scroll.addView(col, ViewGroup.LayoutParams(MP, WC))
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, ins ->
            val b = ins.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            ins
        }
        setContentView(scroll)
    }

    private fun rerender() {
        val y = scroll.scrollY
        render()
        scroll.post { scroll.scrollTo(0, y) }
    }

    private fun preview(t: KbTheme): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = rounded(t.bg, 8)
        box.setPadding(dp(4), dp(4), dp(4), dp(4))
        for (r in 0 until 3) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until 5) {
                val v = View(this)
                val c = if (r == 2 && k == 4) t.action else if (k == 0 && r == 2) t.fn else t.key
                v.background = rounded(c, 3)
                val l = LinearLayout.LayoutParams(0, dp(9), 1f)
                l.setMargins(dp(1), dp(1), dp(1), dp(1))
                row.addView(v, l)
            }
            box.addView(row)
        }
        val l = LinearLayout.LayoutParams(MP, WC)
        box.layoutParams = l
        return box
    }

    private fun toggleRow(title: String, desc: String, key: String, def: Boolean): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(8), 0, dp(8))
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.addView(text(title, 16f))
        c.addView(text(desc, 12f, cSub))
        r.addView(c, LinearLayout.LayoutParams(0, WC, 1f))
        val sw = Switch(this)
        sw.isChecked = sp.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, on -> sp.edit().putBoolean(key, on).apply() }
        r.addView(sw)
        return r
    }

    private fun choiceRow(title: String, key: String, def: String, opts: List<Pair<String, String>>): LinearLayout {
        val cur = sp.getString(key, def) ?: def
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.setPadding(0, dp(8), 0, dp(8))
        r.addView(text(title, 16f))
        r.addView(text(opts.firstOrNull { it.first == cur }?.second ?: "", 13f, cSub))
        r.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(title)
                .setSingleChoiceItems(opts.map { it.second }.toTypedArray(), opts.indexOfFirst { it.first == cur }) { d, w ->
                    sp.edit().putString(key, opts[w].first).apply()
                    d.dismiss()
                    rerender()
                }
                .setNegativeButton("İptal", null)
                .show()
        }
        return r
    }

    private fun choiceRowInt(title: String, key: String, def: Int, opts: List<Pair<Int, String>>): LinearLayout {
        val cur = sp.getInt(key, def)
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.setPadding(0, dp(8), 0, dp(8))
        r.addView(text(title, 16f))
        r.addView(text(opts.firstOrNull { it.first == cur }?.second ?: "", 13f, cSub))
        r.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(title)
                .setSingleChoiceItems(opts.map { it.second }.toTypedArray(), opts.indexOfFirst { it.first == cur }) { d, w ->
                    sp.edit().putInt(key, opts[w].first).apply()
                    d.dismiss()
                    rerender()
                }
                .setNegativeButton("İptal", null)
                .show()
        }
        return r
    }

    private fun refreshStatus() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        val enabled = imm.enabledInputMethodList.any { it.packageName == packageName }
        val def = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
        val selected = def.startsWith(packageName)
        enableTv?.text = if (enabled) "✅ Klavye etkinleştirildi" else "❌ Klavye henüz etkin değil"
        selectTv?.text = if (selected) "✅ Nova Klavye şu an seçili" else "❌ Nova Klavye seçili değil"
    }
}
