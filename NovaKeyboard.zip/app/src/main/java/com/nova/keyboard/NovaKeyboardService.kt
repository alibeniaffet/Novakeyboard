package com.nova.keyboard

import android.annotation.SuppressLint
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.URLEncoder
import java.util.Locale
import kotlin.math.abs

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class NovaKeyboardService : InputMethodService() {

    companion object {
        var instance: NovaKeyboardService? = null
    }

    private enum class Panel { KEYS, EMOJI, CLIP, TRANSLATE, TOOLS }
    private enum class Page { LETTERS, SYM1, SYM2 }
    private enum class Shift { OFF, ONCE, LOCK }

    private class ToolItem(val title: String, val value: String, val act: () -> Unit)

    private lateinit var sp: SharedPreferences
    private lateinit var cm: ClipboardManager
    private lateinit var container: FrameLayout
    private lateinit var body: FrameLayout
    private val handler = Handler(Looper.getMainLooper())

    private var th: KbTheme = Themes.DARK
    private var kbRoot: LinearLayout? = null
    private var panel = Panel.KEYS
    private var page = Page.LETTERS
    private var shift = Shift.OFF
    private var lastShiftTap = 0L
    private var lang = "tr"
    private var sig = ""
    private var bodyH = 0
    private var emojiCat = 0
    private var pending: String? = null

    private val letterKeys = ArrayList<Pair<TextView, String>>()
    private var shiftKey: TextView? = null
    private var enterKey: TextView? = null
    private val toolbarBtns = HashMap<Panel, TextView>()
    private val clips = ArrayList<String>()

    // Kayan mod
    private var popup: PopupWindow? = null
    private var floatW = 0
    private var floatH = 0
    private var offX = 0
    private var offY = 0
    private var lastX = 0
    private var lastY = 0
    private var curSX = 0
    private var curSY = 0

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { captureClip() }

    // ---------------------------------------------------------------- yaşam döngüsü

    override fun onCreate() {
        super.onCreate()
        instance = this
        sp = getSharedPreferences("kb", Context.MODE_PRIVATE)
        cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        dismissFloat()
        try {
            cm.removePrimaryClipChangedListener(clipListener)
        } catch (e: Exception) {
        }
        clips.clear()
        instance = null
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        container = FrameLayout(this)
        rebuild(Panel.KEYS)
        return container
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::container.isInitialized) rebuild(panel)
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        val p = pending
        if (p != null) {
            val ic = currentInputConnection
            if (ic != null) {
                ic.commitText(p, 1)
                pending = null
            }
        }
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!::container.isInitialized) return
        if (computeSig() != sig) rebuild(Panel.KEYS)
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        page = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) Page.SYM1 else Page.LETTERS
        shift = Shift.OFF
        showPanel(Panel.KEYS)
        updateAutoCap()
        if (sp.getBoolean("floating", false)) container.post { showFloat() }
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        dismissFloat()
        super.onFinishInputView(finishingInput)
    }

    override fun onWindowHidden() {
        dismissFloat()
        super.onWindowHidden()
    }

    fun currentLang(): String = lang

    /** Sesli yazma sonucunu alanına yazar. */
    fun deliverText(s: String) {
        val t = s.trim() + " "
        val ic = currentInputConnection
        if (ic != null && isInputViewShown) {
            ic.commitText(t, 1)
        } else {
            pending = t
        }
    }

    // ---------------------------------------------------------------- pano

    private fun captureClip() {
        if (!sp.getBoolean("clip_hist", true)) return
        try {
            val c = cm.primaryClip ?: return
            if (c.itemCount == 0) return
            val sensitive = c.description?.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false) ?: false
            if (sensitive) return
            val t = c.getItemAt(0).coerceToText(this)?.toString() ?: return
            addClip(t)
        } catch (e: Exception) {
        }
    }

    private fun addClip(t: String) {
        if (t.isBlank() || t.length > 2000) return
        clips.remove(t)
        clips.add(0, t)
        while (clips.size > 20) clips.removeAt(clips.size - 1)
    }

    // ---------------------------------------------------------------- kurulum

    private fun computeSig(): String {
        val cfg = resources.configuration
        return listOf(
            sp.getString("theme", "system"),
            sp.getInt("height", 1),
            sp.getString("onehand", "off"),
            sp.getBoolean("floating", false),
            sp.getString("lang", "tr"),
            cfg.uiMode and Configuration.UI_MODE_NIGHT_MASK,
            cfg.orientation,
            cfg.screenWidthDp
        ).joinToString("|")
    }

    private fun rebuild(p: Panel) {
        dismissFloat()
        th = Themes.resolve(this, sp.getString("theme", "system") ?: "system")
        lang = sp.getString("lang", "tr") ?: "tr"
        val keyH = when (sp.getInt("height", 1)) {
            0 -> 40
            2 -> 52
            else -> 46
        }
        bodyH = 5 * dp(keyH + 6) + dp(8)
        sig = computeSig()
        panel = p

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(th.bg)
        root.addView(buildToolbar(), LinearLayout.LayoutParams(MATCH, WRAP))
        body = FrameLayout(this)
        root.addView(body, LinearLayout.LayoutParams(MATCH, bodyH))
        kbRoot = root

        container.removeAllViews()
        container.setBackgroundColor(th.bg)
        val floating = sp.getBoolean("floating", false)
        val one = sp.getString("onehand", "off") ?: "off"
        if (floating) {
            container.setBackgroundColor(0x00000000)
            container.addView(View(this), FrameLayout.LayoutParams(MATCH, dp(2)))
        } else if (one != "off") {
            container.addView(buildOneHanded(root, one), FrameLayout.LayoutParams(MATCH, WRAP))
        } else {
            container.addView(root, FrameLayout.LayoutParams(MATCH, WRAP))
        }
        showPanel(p)
        if (floating && isInputViewShown) container.post { showFloat() }
    }

    private fun buildOneHanded(root: View, side: String): View {
        val h = LinearLayout(this)
        h.orientation = LinearLayout.HORIZONTAL
        h.setBackgroundColor(th.bg)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        fun sideBtn(label: String, a: () -> Unit) {
            val t = TextView(this)
            t.text = label
            t.textSize = 22f
            t.gravity = Gravity.CENTER
            t.setTextColor(th.text)
            t.background = rounded(th.fn, 14)
            val lp = LinearLayout.LayoutParams(MATCH, dp(56))
            lp.setMargins(dp(4), dp(6), dp(4), dp(6))
            t.layoutParams = lp
            t.setOnClickListener {
                feedback(it)
                a()
            }
            col.addView(t)
        }
        sideBtn("⤢") {
            sp.edit().putString("onehand", "off").apply()
            rebuild(panel)
        }
        sideBtn("⇄") {
            sp.edit().putString("onehand", if (side == "left") "right" else "left").apply()
            rebuild(panel)
        }
        val lpKb = LinearLayout.LayoutParams(0, WRAP, 6f)
        val lpSide = LinearLayout.LayoutParams(0, MATCH, 1.3f)
        if (side == "right") {
            h.addView(col, lpSide)
            h.addView(root, lpKb)
        } else {
            h.addView(root, lpKb)
            h.addView(col, lpSide)
        }
        return h
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(radius).toFloat()
        return d
    }

    // ---------------------------------------------------------------- araç çubuğu ve paneller

    private fun buildToolbar(): View {
        toolbarBtns.clear()
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(8), dp(4), dp(8), dp(2))

        fun add(label: String, size: Float, p: Panel?, act: () -> Unit) {
            val t = TextView(this)
            t.text = label
            t.textSize = size
            t.gravity = Gravity.CENTER
            t.setTextColor(th.text)
            val lp = LinearLayout.LayoutParams(0, dp(40), 1f)
            lp.setMargins(dp(3), 0, dp(3), 0)
            t.layoutParams = lp
            t.setOnClickListener {
                feedback(it)
                act()
            }
            row.addView(t)
            if (p != null) toolbarBtns[p] = t
        }
        add("⊞", 22f, Panel.TOOLS) { togglePanel(Panel.TOOLS) }
        add("📋", 18f, Panel.CLIP) { togglePanel(Panel.CLIP) }
        add("文A", 17f, Panel.TRANSLATE) { togglePanel(Panel.TRANSLATE) }
        add("😊", 19f, Panel.EMOJI) { togglePanel(Panel.EMOJI) }
        add("🎤", 18f, null) { startVoice() }
        add("⚙", 21f, null) { openSettings() }
        return row
    }

    private fun togglePanel(p: Panel) {
        showPanel(if (panel == p) Panel.KEYS else p)
    }

    private fun showPanel(p: Panel) {
        panel = p
        body.removeAllViews()
        val v = when (p) {
            Panel.KEYS -> buildKeys()
            Panel.EMOJI -> buildEmoji()
            Panel.CLIP -> buildClip()
            Panel.TRANSLATE -> buildTranslate()
            Panel.TOOLS -> buildTools()
        }
        body.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        for ((k, b) in toolbarBtns) {
            b.background = if (k == panel && panel != Panel.KEYS) rounded(th.fn, 20) else null
        }
    }

    // ---------------------------------------------------------------- tuşlar

    private fun hrow(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.layoutParams = LinearLayout.LayoutParams(MATCH, 0, 1f)
        return r
    }

    private fun keyColor(kind: Int, pressed: Boolean): Int {
        if (pressed) return th.pressed
        return when (kind) {
            1 -> th.fn
            2 -> th.action
            else -> th.key
        }
    }

    private fun setKeyBg(t: TextView, kind: Int, pressed: Boolean) {
        t.background = rounded(keyColor(kind, pressed), 9)
    }

    private fun makeKey(label: String, weight: Float, kind: Int, size: Float): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = size
        t.gravity = Gravity.CENTER
        t.setTextColor(if (kind == 2) th.actionText else th.text)
        setKeyBg(t, kind, false)
        val lp = LinearLayout.LayoutParams(0, MATCH, weight)
        lp.setMargins(dp(3), dp(3), dp(3), dp(3))
        t.layoutParams = lp
        return t
    }

    private fun feedback(v: View) {
        if (sp.getBoolean("haptic", true)) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        if (sp.getBoolean("sound", false)) {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD, -1f)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun bind(t: TextView, kind: Int, repeat: Boolean = false, onLong: (() -> Unit)? = null, action: () -> Unit) {
        var longFired = false
        var rep: Runnable? = null
        val longRun = Runnable {
            longFired = true
            feedback(t)
            onLong?.invoke()
        }
        t.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    setKeyBg(t, kind, true)
                    longFired = false
                    feedback(v)
                    if (repeat) {
                        action()
                        val r = object : Runnable {
                            override fun run() {
                                action()
                                handler.postDelayed(this, 45L)
                            }
                        }
                        rep = r
                        handler.postDelayed(r, 380L)
                    } else if (onLong != null) {
                        handler.postDelayed(longRun, 420L)
                    } else {
                        action()
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    setKeyBg(t, kind, false)
                    handler.removeCallbacks(longRun)
                    val r = rep
                    if (r != null) handler.removeCallbacks(r)
                    rep = null
                    if (e.actionMasked == MotionEvent.ACTION_UP && onLong != null && !longFired && !repeat) action()
                    true
                }
                else -> true
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun bindSpace(t: TextView) {
        var downX = 0f
        var moved = false
        var steps = 0
        var longFired = false
        val longRun = Runnable {
            longFired = true
            showPicker()
        }
        t.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    moved = false
                    steps = 0
                    longFired = false
                    setKeyBg(t, 0, true)
                    feedback(v)
                    handler.postDelayed(longRun, 550L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    if (abs(dx) > dp(10)) {
                        moved = true
                        handler.removeCallbacks(longRun)
                    }
                    if (moved) {
                        val s = (dx / dp(16)).toInt()
                        if (s != steps) {
                            val diff = s - steps
                            for (i in 0 until abs(diff)) {
                                sendDownUpKeyEvents(if (diff > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT)
                            }
                            steps = s
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    setKeyBg(t, 0, false)
                    handler.removeCallbacks(longRun)
                    if (e.actionMasked == MotionEvent.ACTION_UP && !moved && !longFired) {
                        commit(" ")
                        updateAutoCap()
                    }
                    true
                }
                else -> true
            }
        }
    }

    private fun buildKeys(): View {
        letterKeys.clear()
        shiftKey = null
        enterKey = null
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(3), dp(3), dp(3), dp(3))

        // Sayı satırı
        val nr = hrow()
        for (ch in "1234567890") {
            val k = makeKey(ch.toString(), 1f, 0, 19f)
            bind(k, 0) { typeText(ch.toString()) }
            nr.addView(k)
        }
        col.addView(nr)

        val letters = page == Page.LETTERS
        val tr = lang == "tr"
        val rows: Array<String> = when (page) {
            Page.LETTERS ->
                if (tr) arrayOf("qwertyuıopğü", "asdfghjklşi", "zxcvbnmöç")
                else arrayOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
            Page.SYM1 -> arrayOf("@#₺_&-+()/", "*\":;!?%=\\", "'…,.~|`")
            Page.SYM2 -> arrayOf("€£¥¢^°{}[]", "©®™✓•√π÷×", "<>±¶∆§¿")
        }

        fun charKey(ch: Char): TextView {
            val k = makeKey(ch.toString(), 1f, 0, 22f)
            if (letters) {
                letterKeys.add(Pair(k, ch.toString()))
                bind(k, 0) { typeLetter(ch.toString()) }
            } else {
                bind(k, 0) { typeText(ch.toString()) }
            }
            return k
        }

        val r1 = hrow()
        for (ch in rows[0]) r1.addView(charKey(ch))
        col.addView(r1)

        val r2 = hrow()
        val pad = (rows[0].length - rows[1].length) / 2f
        if (pad > 0f) r2.addView(spacer(pad))
        for (ch in rows[1]) r2.addView(charKey(ch))
        if (pad > 0f) r2.addView(spacer(pad))
        col.addView(r2)

        val r3 = hrow()
        if (letters) {
            val sk = makeKey("⇧", 1.5f, 1, 20f)
            bind(sk, 1) { onShift() }
            shiftKey = sk
            r3.addView(sk)
        } else {
            val label = if (page == Page.SYM1) "=\\<" else "?123"
            val pk = makeKey(label, 1.5f, 1, 15f)
            bind(pk, 1) {
                page = if (page == Page.SYM1) Page.SYM2 else Page.SYM1
                showPanel(Panel.KEYS)
            }
            r3.addView(pk)
        }
        for (ch in rows[2]) r3.addView(charKey(ch))
        val del = makeKey("⌫", 1.5f, 1, 19f)
        bind(del, 1, true) { doDelete() }
        r3.addView(del)
        col.addView(r3)

        // Alt satır
        val r4 = hrow()
        val sym = makeKey(if (letters) "?123" else "ABC", 1.5f, 1, 15f)
        bind(sym, 1) {
            page = if (letters) Page.SYM1 else Page.LETTERS
            showPanel(Panel.KEYS)
        }
        r4.addView(sym)

        val comma = makeKey(",", 1f, 1, 20f)
        bind(comma, 1, false, { showPanel(Panel.EMOJI) }) { typeText(",") }
        r4.addView(comma)

        val globe = makeKey("🌐", 1f, 1, 18f)
        bind(globe, 1, false, { showPicker() }) { toggleLang() }
        r4.addView(globe)

        val space = makeKey(if (tr) "Türkçe" else "English", 4.5f, 0, 14f)
        space.setTextColor(th.sub)
        bindSpace(space)
        r4.addView(space)

        val dot = makeKey(".", 1f, 1, 20f)
        bind(dot, 1) { typeText(".") }
        r4.addView(dot)

        val enter = makeKey("↵", 1.5f, 2, 20f)
        bind(enter, 2) { onEnter() }
        enterKey = enter
        r4.addView(enter)
        col.addView(r4)

        refreshShift()
        updateEnterKey(currentInputEditorInfo)
        return col
    }

    private fun spacer(w: Float): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(0, 1, w)
        return v
    }

    // ---------------------------------------------------------------- yazma

    private fun commit(s: String) {
        currentInputConnection?.commitText(s, 1)
    }

    private fun upper(s: String): String = s.uppercase(if (lang == "tr") Locale("tr", "TR") else Locale.ENGLISH)

    private fun typeText(s: String) {
        commit(s)
        updateAutoCap()
    }

    private fun typeLetter(base: String) {
        commit(if (shift != Shift.OFF) upper(base) else base)
        if (shift == Shift.ONCE) {
            shift = Shift.OFF
            refreshShift()
        }
    }

    private fun onShift() {
        val now = SystemClock.uptimeMillis()
        shift = when {
            shift == Shift.LOCK -> Shift.OFF
            shift == Shift.ONCE && now - lastShiftTap < 350L -> Shift.LOCK
            shift == Shift.ONCE -> Shift.OFF
            else -> Shift.ONCE
        }
        lastShiftTap = now
        refreshShift()
    }

    private fun refreshShift() {
        for ((v, base) in letterKeys) {
            v.text = if (shift != Shift.OFF) upper(base) else base
        }
        val sk = shiftKey ?: return
        sk.text = when (shift) {
            Shift.OFF -> "⇧"
            Shift.ONCE -> "⬆"
            Shift.LOCK -> "⇪"
        }
        sk.background = rounded(if (shift == Shift.OFF) th.fn else th.action, 9)
        sk.setTextColor(if (shift == Shift.OFF) th.text else th.actionText)
    }

    private fun updateAutoCap() {
        if (!sp.getBoolean("autocap", true) || shift == Shift.LOCK || page != Page.LETTERS) return
        val ei = currentInputEditorInfo ?: return
        val ic = currentInputConnection ?: return
        if ((ei.inputType and InputType.TYPE_MASK_CLASS) != InputType.TYPE_CLASS_TEXT) return
        val caps = ic.getCursorCapsMode(ei.inputType)
        val want = if (caps != 0) Shift.ONCE else Shift.OFF
        if (shift != want) {
            shift = want
            refreshShift()
        }
    }

    private fun doDelete() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (sel != null && sel.isNotEmpty()) {
            ic.commitText("", 1)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
        updateAutoCap()
    }

    private fun onEnter() {
        val ei = currentInputEditorInfo
        val ic = currentInputConnection ?: return
        if (ei == null) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
            return
        }
        val action = ei.imeOptions and EditorInfo.IME_MASK_ACTION
        val noAction = (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (noAction || action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        } else {
            ic.performEditorAction(action)
        }
        updateAutoCap()
    }

    private fun updateEnterKey(ei: EditorInfo?) {
        val k = enterKey ?: return
        if (ei == null) return
        val action = ei.imeOptions and EditorInfo.IME_MASK_ACTION
        val noAction = (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        k.text = if (noAction) "↵" else when (action) {
            EditorInfo.IME_ACTION_GO -> "➜"
            EditorInfo.IME_ACTION_SEARCH -> "🔍"
            EditorInfo.IME_ACTION_SEND -> "➤"
            EditorInfo.IME_ACTION_NEXT -> "→"
            EditorInfo.IME_ACTION_DONE -> "✓"
            else -> "↵"
        }
    }

    private fun toggleLang() {
        lang = if (lang == "tr") "en" else "tr"
        sp.edit().putString("lang", lang).apply()
        sig = computeSig()
        showPanel(Panel.KEYS)
    }

    private fun showPicker() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showInputMethodPicker()
    }

    private fun openSettings() {
        val i = Intent(this, SetupActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    private fun startVoice() {
        val i = Intent(this, VoiceActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    // ---------------------------------------------------------------- emoji

    private fun buildEmoji(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        val sv = ScrollView(this)
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        grid.setPadding(dp(4), dp(4), dp(4), dp(4))
        sv.addView(grid, ViewGroup.LayoutParams(MATCH, WRAP))
        col.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.gravity = Gravity.CENTER_VERTICAL
        tabs.setPadding(dp(4), dp(2), dp(4), dp(4))
        col.addView(tabs, LinearLayout.LayoutParams(MATCH, dp(46)))

        val tabViews = ArrayList<TextView>()

        fun fill() {
            grid.removeAllViews()
            val list = EmojiData.CATS[emojiCat].second
            var i = 0
            while (i < list.size) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                for (j in 0 until 8) {
                    val t = TextView(this)
                    t.gravity = Gravity.CENTER
                    t.textSize = 25f
                    if (i + j < list.size) {
                        val e = list[i + j]
                        t.text = e
                        t.setOnClickListener {
                            feedback(it)
                            commit(e)
                        }
                    }
                    row.addView(t, LinearLayout.LayoutParams(0, dp(46), 1f))
                }
                grid.addView(row)
                i += 8
            }
            for (k in tabViews.indices) {
                tabViews[k].background = if (k == emojiCat) rounded(th.fn, 12) else null
            }
            sv.scrollTo(0, 0)
        }

        val abc = makeKey("ABC", 1.4f, 1, 14f)
        bind(abc, 1) { showPanel(Panel.KEYS) }
        tabs.addView(abc)
        for (idx in EmojiData.CATS.indices) {
            val t = TextView(this)
            t.text = EmojiData.CATS[idx].first
            t.textSize = 18f
            t.gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(0, MATCH, 1f)
            lp.setMargins(dp(1), dp(3), dp(1), dp(3))
            t.layoutParams = lp
            t.setOnClickListener {
                feedback(it)
                emojiCat = idx
                fill()
            }
            tabViews.add(t)
            tabs.addView(t)
        }
        val del = makeKey("⌫", 1.4f, 1, 18f)
        bind(del, 1, true) { doDelete() }
        tabs.addView(del)

        if (emojiCat >= EmojiData.CATS.size) emojiCat = 0
        fill()
        return col
    }

    // ---------------------------------------------------------------- pano

    private fun buildClip(): View {
        if (sp.getBoolean("clip_hist", true)) {
            try {
                val c = cm.primaryClip
                if (c != null && c.itemCount > 0) {
                    val sensitive = c.description?.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false) ?: false
                    val t = c.getItemAt(0).coerceToText(this)?.toString()
                    if (!sensitive && t != null && !clips.contains(t)) addClip(t)
                }
            } catch (e: Exception) {
            }
        }

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(10), dp(4), dp(10), dp(4))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = label("Pano", 17f, th.text, true)
        head.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        val clear = label("Temizle", 14f, th.actionText, false)
        clear.background = rounded(th.action, 16)
        clear.setPadding(dp(14), dp(6), dp(14), dp(6))
        clear.setOnClickListener {
            clips.clear()
            showPanel(Panel.CLIP)
        }
        head.addView(clear)
        val back = label("ABC", 14f, th.text, false)
        back.background = rounded(th.fn, 16)
        back.setPadding(dp(14), dp(6), dp(14), dp(6))
        back.setOnClickListener { showPanel(Panel.KEYS) }
        val lpBack = LinearLayout.LayoutParams(WRAP, WRAP)
        lpBack.leftMargin = dp(8)
        head.addView(back, lpBack)
        col.addView(head)

        col.addView(label("Yalnızca bellekte tutulur; klavye kapanınca silinir.", 11f, th.sub, false))

        val sv = ScrollView(this)
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        sv.addView(list, ViewGroup.LayoutParams(MATCH, WRAP))
        col.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))

        if (clips.isEmpty()) {
            val e = label("Pano boş. Bir şey kopyalayınca burada görünür.", 14f, th.sub, false)
            e.setPadding(0, dp(20), 0, 0)
            list.addView(e)
        }
        for (c in clips.toList()) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = rounded(th.key, 10)
            row.setPadding(dp(12), dp(8), dp(4), dp(8))
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.topMargin = dp(5)
            row.layoutParams = lp
            val t = label(c, 14f, th.text, false)
            t.maxLines = 3
            t.ellipsize = TextUtils.TruncateAt.END
            row.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
            val x = label("✕", 15f, th.sub, false)
            x.setPadding(dp(14), dp(6), dp(14), dp(6))
            x.setOnClickListener {
                clips.remove(c)
                showPanel(Panel.CLIP)
            }
            row.addView(x)
            row.setOnClickListener {
                feedback(it)
                commit(c)
            }
            list.addView(row)
        }
        return col
    }

    private fun label(s: String, size: Float, color: Int, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        return t
    }

    // ---------------------------------------------------------------- çeviri

    private fun textToTranslate(): String {
        val ic = currentInputConnection ?: return ""
        val sel = ic.getSelectedText(0)
        if (sel != null && sel.isNotEmpty()) return sel.toString()
        val b = ic.getTextBeforeCursor(1500, 0)?.toString() ?: ""
        val a = ic.getTextAfterCursor(1500, 0)?.toString() ?: ""
        return (b + a).trim()
    }

    private fun buildTranslate(): View {
        val src = textToTranslate()
        val target = sp.getString("target", "en") ?: "en"
        val langs = listOf(
            "tr" to "Türkçe", "en" to "English", "de" to "Deutsch", "fr" to "Français",
            "es" to "Español", "it" to "Italiano", "ru" to "Русский", "ar" to "العربية"
        )

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(10), dp(4), dp(10), dp(4))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(label("Çeviri", 17f, th.text, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        val back = label("ABC", 14f, th.text, false)
        back.background = rounded(th.fn, 16)
        back.setPadding(dp(14), dp(6), dp(14), dp(6))
        back.setOnClickListener { showPanel(Panel.KEYS) }
        head.addView(back)
        col.addView(head)

        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        for ((code, name) in langs) {
            val c = label(name, 13f, if (code == target) th.actionText else th.text, false)
            c.background = rounded(if (code == target) th.action else th.fn, 16)
            c.setPadding(dp(12), dp(6), dp(12), dp(6))
            val lp = LinearLayout.LayoutParams(WRAP, WRAP)
            lp.setMargins(0, dp(6), dp(6), dp(6))
            c.layoutParams = lp
            c.setOnClickListener {
                sp.edit().putString("target", code).apply()
                showPanel(Panel.TRANSLATE)
            }
            chips.addView(c)
        }
        hs.addView(chips)
        col.addView(hs)

        val preview = label(
            if (src.isBlank()) "Çevrilecek metin yok. Bir şey yaz veya seç, sonra buraya dön." else src,
            13f, if (src.isBlank()) th.sub else th.text, false
        )
        preview.maxLines = 3
        preview.ellipsize = TextUtils.TruncateAt.END
        preview.background = rounded(th.key, 10)
        preview.setPadding(dp(10), dp(8), dp(10), dp(8))
        col.addView(preview, LinearLayout.LayoutParams(MATCH, WRAP))

        val btns = LinearLayout(this)
        btns.orientation = LinearLayout.HORIZONTAL
        val b1 = label("Çeviri uygulamasında aç", 13f, th.actionText, true)
        b1.gravity = Gravity.CENTER
        b1.background = rounded(th.action, 12)
        b1.setPadding(dp(8), dp(12), dp(8), dp(12))
        b1.setOnClickListener {
            feedback(it)
            if (src.isBlank()) {
                toast("Önce metin yaz")
            } else {
                openTranslate(src, target)
            }
        }
        val b2 = label("Çeviriyi yapıştır", 13f, th.text, true)
        b2.gravity = Gravity.CENTER
        b2.background = rounded(th.fn, 12)
        b2.setPadding(dp(8), dp(12), dp(8), dp(12))
        b2.setOnClickListener {
            feedback(it)
            pasteTranslation()
        }
        val lp1 = LinearLayout.LayoutParams(0, WRAP, 1f)
        lp1.rightMargin = dp(6)
        val lp2 = LinearLayout.LayoutParams(0, WRAP, 1f)
        btns.addView(b1, lp1)
        btns.addView(b2, lp2)
        val lpb = LinearLayout.LayoutParams(MATCH, WRAP)
        lpb.topMargin = dp(8)
        col.addView(btns, lpb)

        val note = label(
            "Klavyenin internet izni yok. Çeviri Google Çeviri'de yapılır: metni orada kopyala, geri dönüp “Çeviriyi yapıştır”a dokun.",
            11f, th.sub, false
        )
        note.setPadding(0, dp(8), 0, 0)
        col.addView(note)
        return col
    }

    private fun openTranslate(src: String, target: String) {
        val url = "https://translate.google.com/?sl=auto&tl=$target&text=" +
            URLEncoder.encode(src, "UTF-8") + "&op=translate"
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            toast("Çeviri açılamadı")
        }
    }

    private fun pasteTranslation() {
        val ic = currentInputConnection ?: return
        var t: String? = null
        try {
            val c = cm.primaryClip
            if (c != null && c.itemCount > 0) t = c.getItemAt(0).coerceToText(this)?.toString()
        } catch (e: Exception) {
        }
        if (t.isNullOrBlank()) {
            toast("Panoda çeviri yok")
            return
        }
        val sel = ic.getSelectedText(0)
        if (sel == null || sel.isEmpty()) ic.performContextMenuAction(android.R.id.selectAll)
        ic.commitText(t, 1)
        showPanel(Panel.KEYS)
    }

    // ---------------------------------------------------------------- araçlar

    private fun buildTools(): View {
        val oh = sp.getString("onehand", "off") ?: "off"
        val themeName = sp.getString("theme", "system") ?: "system"
        val height = sp.getInt("height", 1)
        val items = listOf(
            ToolItem("🤏 Tek el modu", when (oh) { "left" -> "Sol"; "right" -> "Sağ"; else -> "Kapalı" }) {
                val n = when (oh) { "off" -> "right"; "right" -> "left"; else -> "off" }
                sp.edit().putString("onehand", n).apply()
                rebuild(Panel.TOOLS)
            },
            ToolItem("🪟 Kayan mod", if (sp.getBoolean("floating", false)) "Açık" else "Kapalı") {
                sp.edit().putBoolean("floating", !sp.getBoolean("floating", false)).apply()
                rebuild(Panel.TOOLS)
            },
            ToolItem("🎨 Tema", Themes.label(themeName)) {
                val order = listOf("system", "dark", "light", "black")
                val n = order[(order.indexOf(themeName) + 1) % order.size]
                sp.edit().putString("theme", n).apply()
                rebuild(Panel.TOOLS)
            },
            ToolItem("↕ Yükseklik", when (height) { 0 -> "Küçük"; 2 -> "Büyük"; else -> "Orta" }) {
                sp.edit().putInt("height", (height + 1) % 3).apply()
                rebuild(Panel.TOOLS)
            },
            ToolItem("📳 Titreşim", if (sp.getBoolean("haptic", true)) "Açık" else "Kapalı") {
                sp.edit().putBoolean("haptic", !sp.getBoolean("haptic", true)).apply()
                showPanel(Panel.TOOLS)
            },
            ToolItem("🌐 Dil", if (lang == "tr") "Türkçe" else "English") {
                toggleLang()
                showPanel(Panel.TOOLS)
            },
            ToolItem("🧹 Panoyu sil", "${clips.size} öğe") {
                clips.clear()
                showPanel(Panel.TOOLS)
            },
            ToolItem("⚙ Ayarlar", "Tema, gizlilik…") { openSettings() },
            ToolItem("⌨ Klavye değiştir", "Başka klavyeye geç") { showPicker() }
        )

        val sv = ScrollView(this)
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        grid.setPadding(dp(8), dp(4), dp(8), dp(8))
        sv.addView(grid, ViewGroup.LayoutParams(MATCH, WRAP))

        var i = 0
        while (i < items.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (j in 0 until 2) {
                if (i + j < items.size) {
                    val item = items[i + j]
                    val card = LinearLayout(this)
                    card.orientation = LinearLayout.VERTICAL
                    card.background = rounded(th.key, 12)
                    card.setPadding(dp(12), dp(10), dp(12), dp(10))
                    card.addView(label(item.title, 15f, th.text, true))
                    card.addView(label(item.value, 12f, th.sub, false))
                    card.setOnClickListener { v ->
                        feedback(v)
                        item.act()
                    }
                    val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
                    lp.setMargins(dp(4), dp(4), dp(4), dp(4))
                    row.addView(card, lp)
                } else {
                    row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
                }
            }
            grid.addView(row)
            i += 2
        }
        return sv
    }

    // ---------------------------------------------------------------- kayan mod

    @SuppressLint("ClickableViewAccessibility")
    private fun showFloat() {
        if (popup != null) return
        if (!sp.getBoolean("floating", false)) return
        val root = kbRoot ?: return
        if (!container.isAttachedToWindow) return
        (root.parent as? ViewGroup)?.removeView(root)

        val dm = resources.displayMetrics
        val w = minOf((dm.widthPixels * 0.94f).toInt(), dp(520))
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL
        val bgd = GradientDrawable()
        bgd.setColor(th.bg)
        bgd.cornerRadius = dp(16).toFloat()
        bgd.setStroke(dp(1), th.pressed)
        wrap.background = bgd

        val handle = LinearLayout(this)
        handle.orientation = LinearLayout.HORIZONTAL
        handle.gravity = Gravity.CENTER_VERTICAL
        val grip = label("━━━", 16f, th.sub, false)
        grip.gravity = Gravity.CENTER
        handle.addView(grip, LinearLayout.LayoutParams(0, MATCH, 1f))
        val dock = label("⤓", 18f, th.text, false)
        dock.gravity = Gravity.CENTER
        dock.setPadding(dp(14), 0, dp(14), 0)
        dock.setOnClickListener {
            sp.edit().putBoolean("floating", false).apply()
            rebuild(panel)
        }
        handle.addView(dock, LinearLayout.LayoutParams(WRAP, MATCH))
        wrap.addView(handle, LinearLayout.LayoutParams(MATCH, dp(30)))
        wrap.addView(root, LinearLayout.LayoutParams(MATCH, WRAP))

        var dx0 = 0f
        var dy0 = 0f
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx0 = e.rawX
                    dy0 = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    moveFloat(curSX + (e.rawX - dx0).toInt(), curSY + (e.rawY - dy0).toInt(), false)
                    dx0 = e.rawX
                    dy0 = e.rawY
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    sp.edit().putInt("float_x", curSX).putInt("float_y", curSY).apply()
                    true
                }
                else -> true
            }
        }

        wrap.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        floatW = w
        floatH = wrap.measuredHeight

        val pw = PopupWindow(wrap, w, WRAP)
        pw.isFocusable = false
        pw.isTouchable = true
        pw.isOutsideTouchable = false
        pw.isClippingEnabled = false
        pw.inputMethodMode = PopupWindow.INPUT_METHOD_NOT_NEEDED
        pw.elevation = dp(12).toFloat()
        popup = pw
        lastX = 0
        lastY = 0
        offX = 0
        offY = 0
        try {
            pw.showAtLocation(container, Gravity.TOP or Gravity.START, 0, 0)
        } catch (e: Exception) {
            popup = null
            return
        }
        handler.postDelayed({
            val p = popup
            if (p != null) {
                val loc = IntArray(2)
                wrap.getLocationOnScreen(loc)
                offX = loc[0] - lastX
                offY = loc[1] - lastY
                val sx = sp.getInt("float_x", -1)
                val sy = sp.getInt("float_y", -1)
                val dx = if (sx >= 0) sx else (dm.widthPixels - floatW) / 2
                val dy = if (sy >= 0) sy else dm.heightPixels - floatH - dp(120)
                moveFloat(dx, dy, true)
            }
        }, 80L)
    }

    private fun moveFloat(sx: Int, sy: Int, force: Boolean) {
        val p = popup ?: return
        val dm = resources.displayMetrics
        val x = sx.coerceIn(0, maxOf(0, dm.widthPixels - floatW))
        val y = sy.coerceIn(0, maxOf(0, dm.heightPixels - floatH))
        if (!force && x == curSX && y == curSY) return
        curSX = x
        curSY = y
        lastX = x - offX
        lastY = y - offY
        try {
            p.update(lastX, lastY, -1, -1)
        } catch (e: Exception) {
        }
    }

    private fun dismissFloat() {
        val p = popup ?: return
        popup = null
        try {
            p.dismiss()
        } catch (e: Exception) {
        }
    }
}
