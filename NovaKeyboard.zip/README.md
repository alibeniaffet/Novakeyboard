# Nova Klavye

Gizlilik odaklı Android klavyesi.
- Kelime öğrenme/öneri/geçmiş yok; internet yalnızca çeviri için
- Türkçe + İngilizce QWERTY, sayı satırı, sembol sayfaları
- Emoji, pano (yalnızca bellekte), çeviri, sesli yazma
- Tek el modu, kayan mod (deneysel)
- Temalar: Sistem, Koyu, Açık, Siyah
