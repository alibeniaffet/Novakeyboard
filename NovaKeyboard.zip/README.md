# Nova Klavye

Gizlilik odaklı Android klavyesi.
- İnternet izni yok, kelime öğrenme/öneri/geçmiş yok
- Türkçe + İngilizce QWERTY, sayı satırı, sembol sayfaları
- Emoji, pano (yalnızca bellekte), çeviri, sesli yazma
- Tek el modu, kayan mod (deneysel)
- Temalar: Sistem, Koyu, Açık, Siyah
